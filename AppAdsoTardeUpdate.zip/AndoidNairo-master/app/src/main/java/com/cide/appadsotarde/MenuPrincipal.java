package com.cide.appadsotarde;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MenuPrincipal extends AppCompatActivity {

    Button btnregresar;
    Button btninsertar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);

        btnregresar = findViewById(R.id.btnregresar);
        btninsertar = findViewById(R.id.btnRegistrar);

        btnregresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(MenuPrincipal.this, "GOOD BYE", Toast.LENGTH_SHORT).show();

                /* pasar de una pagina a otra*/
                startActivity(new Intent(MenuPrincipal.this,MainActivity.class));

            }




        });
        btninsertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),prueba.class);
                startActivity(intent);
            }
        });
    }


    }









