package com.cide.appadsotarde;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class contactanos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contactanos);
    }
}