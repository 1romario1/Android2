package com.cide.appadsotarde;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;



public class index extends AppCompatActivity {

    Button buttonnuestrohotel,buttonservicios,buttonregresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index);
        buttonnuestrohotel = findViewById(R.id.buttonnuestrohotel);
        buttonservicios = findViewById(R.id.buttonservicios);
        buttonregresar = findViewById(R.id.buttonregresar);

        buttonnuestrohotel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),NuestroHotel.class);
                startActivity(intent);
            }
        });


        buttonservicios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),servicios2.class);
                startActivity(intent);
            }
        });

        buttonregresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),principal.class);
                startActivity(intent);
            }
        });
    }
}