package com.cide.appadsotarde;

import androidx.appcompat.app.AppCompatActivity;



import androidx.annotation.Nullable;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import java.util.HashMap;
import java.util.Map;

public class prueba extends AppCompatActivity {

    Button btnEviar;

    EditText cajaNumeroDocumento, cajanombre, cajaApellido, cajaEmail, cajaTelefono, cajaCalle, cajaNumero,cajaContraseña, cajaNacimiento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prueba);

        cajaNumeroDocumento = findViewById(R.id.cajaNumeroDocumento);
        cajanombre = findViewById(R.id.cajanombre);
        cajaApellido = findViewById(R.id.cajaApellido);
        cajaEmail = findViewById(R.id.cajaEmail);
        cajaTelefono = findViewById(R.id.cajaTelefono);
        cajaCalle = findViewById(R.id.cajaCalle);
        cajaNumero = findViewById(R.id.cajaNumero);
        cajaContraseña = findViewById(R.id.cajaContraseña);
        cajaNacimiento = findViewById(R.id.cajaNacimiento);




        btnEviar = findViewById(R.id.btnEviar);


        btnEviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertarUsuario("https://lodgingrslr.000webhostapp.com/insertar2.php");
            }
        });
    }

    private void insertarUsuario(String URL) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST,URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "Insercion correctamente realizada", Toast.LENGTH_SHORT).show();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Se ha identificado un error", Toast.LENGTH_SHORT).show();
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> parametros = new HashMap<String, String>();

                parametros.put("Nro_Documento", cajaNumeroDocumento.getText().toString());
                parametros.put("Nombre", cajanombre.getText().toString());
                parametros.put("Apellido", cajaApellido.getText().toString());
                parametros.put("Email", cajaEmail.getText().toString());
                parametros.put("Telefono", cajaTelefono.getText().toString());
                parametros.put("Calle", cajaCalle.getText().toString());
                parametros.put("Numero", cajaNumero.getText().toString());
                parametros.put("Contraseña", cajaContraseña.getText().toString());
                parametros.put("Fecha_de_Restablecimiento", cajaNacimiento.getText().toString());




                return parametros;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public static class servicios {
    }
}